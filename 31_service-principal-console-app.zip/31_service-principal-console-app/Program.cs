﻿
using Azure.Identity;
using Azure.Storage.Blobs;

string tenantId = "ae6cba77-f65c-49f3-b41d-37f9945b7135";
string clientId = "dd1f2c57-ce7c-4689-b8b1-e5f770964aa9";
string clientSecret = "ZM48Q~njmOovSk~b2~FeMYfUmf5PHkoZw6WZccsh";



string blobURI = "https://siemensstorageacc0949.blob.core.windows.net/images/01-IAAS.png";
string filePath = "D:\\Training\\Siemens\\Azure Developer\\Batch-2\\Temp\\newblob.png";
ClientSecretCredential clientCredential = new ClientSecretCredential(tenantId, clientId, clientSecret);

BlobClient blobClient = new BlobClient(new Uri(blobURI), clientCredential);

await blobClient.DownloadToAsync(filePath);

Console.WriteLine("The blob is downloaded");

