﻿//sender connection string:
using Azure.Messaging.ServiceBus;

const string connectionString = "Endpoint=sb://siemensbus.servicebus.windows.net/;SharedAccessKeyName=queue-policy;SharedAccessKey=6hGzLXYyIo4lfjdVmKKA8XEP4LIunHYmV+ASbL/TM8U=;EntityPath=queue1";
const string queueName = "queue1";
ServiceBusClient? client = default;
ServiceBusSender? sender = default;
const int numOfMessages = 10;
client = new ServiceBusClient(connectionString);
sender = client.CreateSender(queueName);

using ServiceBusMessageBatch messageBatch = await sender.CreateMessageBatchAsync();

for (int i = 1; i <= numOfMessages; i++)
{
    ServiceBusMessage message = new ServiceBusMessage($"Message {i}");
    message.MessageId =  "Kfksjdf"+i.ToString();
    message.PartitionKey = "part1"; ;
    if (!messageBatch.TryAddMessage(message))
    {
        throw new Exception($"The message {i} is too large to fit in the batch.");
    }
}
try
{
    await sender.SendMessagesAsync(messageBatch);
    Console.WriteLine($"A batch of {numOfMessages} messages has been published to the queue.");
}
finally
{
    await sender.DisposeAsync();
    await client.DisposeAsync();
}